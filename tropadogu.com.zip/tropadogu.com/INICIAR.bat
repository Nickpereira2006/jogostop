@echo off
title Site de Jogos - Servidor Local
cd /d "%~dp0"

echo.
echo  ============================================
echo    SITE DE JOGOS - Servidor Local
echo  ============================================
echo.

netstat -ano | findstr ":8080" | findstr "LISTENING" >nul
if %errorlevel%==0 (
  echo  Servidor ja esta rodando. Abrindo navegador...
  start "" http://localhost:8080
  timeout /t 3 >nul
  exit /b
)

echo  Iniciando servidor na porta 8080...
start "" http://localhost:8080
node servidor.js

pause
